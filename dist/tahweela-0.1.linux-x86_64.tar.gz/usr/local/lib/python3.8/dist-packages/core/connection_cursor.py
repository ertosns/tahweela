import psycopg2 as pg
from core.utils import db_configs

conn = pg.connect(db_configs)
#conn = pg.connect("dbname='demo'  user='tahweela' password='tahweela'")
cur=conn.cursor()

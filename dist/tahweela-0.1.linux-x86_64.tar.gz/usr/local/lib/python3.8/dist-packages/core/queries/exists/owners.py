from core.connection_cursor import cur

def exists():
    pass

from ...connection_cursor import currency

def insert_trx(des, src, gid):
    """ insert transaction from 'src' to 'des' for good with 'gid'

    @param des: the transaction destination
    @param src: the transaction source
    @param gid: the good's id
    """
    stat="INSERT INTO ledger (trx_dest, trx_src, good_id) VALUES ('{}', '{}', '{}')".\
        format(des, src, gid)
    cur.execute(stat)

from ...connection_cursor import cur

def insert_contact(cid, cname, bid):
    """ insert new contact (CALLED AT THE CLIENT SIDE)

    @param cid: contact id
    @param cname: contact name
    @param bid: bank account id
    """
    stat="INSERT INTO contacts (contact_id, contact_name bank_account_id) VALUES ('{}', '{}', '{}')".format(cid, cname, bid)
    cur.execute(stat)

from ...connection_cursor import cur
#TOOD move random to the __init__ in the start of package, and seed it randomly
import random as rand
from ...utils import MAX_CRED_ID
import string

def register(cid):
    """register new client with given cid (CALLED FROM SERVER SIDE)

    @param cid: client id
    @return (cred_id, passcode)
    """
    cred_id=rand.random()*MAX_CRED_ID
    passcode=''.join(rand.choice(string.ascii_uppercase+string.ascii_lowercase+string.digits) for _ in range(9))
    stat="INSRET INTO credentials (id, passcode, cred_id) VALUES {}".\
        format((cid, passcode, cred_id))
    cur.execute(stat)
    return (cred_id, passcode)

def add_cred(passcode, cred_id):
    """add client credentials returned from the server(CALLED FROM SERVER SIDE)

    @param cid: client id
    """
    stat="INSRET INTO credentials (passcode, cred_id) VALUES {}".\
        format((passcode, cred_id))
    cur.execute(stat)

from ...connection_cursor import cur

def exists(cid):
    """verify that  a client with given id is available (CALLED AT THE SERVER SIDE)

    @param cid: client id
    @return boolean wither the client exists or note
    """
    stat="SELECT EXISTS (SELECT 1 FROM clients WHERE id='{}');".format(cid)
    cur.execute(stat)
    return cur.fetchone()[0]

import datetime as dt
from ...connection_cursor import cur
from ...utils import TIMESTAMP_FORMAT

def update_account(cid, balance):
    """update the banking account with the calculated new balance (CALLED FROM SERVER SIDE)

    @param cid: client id
    @param balance: the account balance
    """
    stat = "UPDATE banking SET (balance, balance_dt) = {} WHERE client_id={}".\
        format((balance, dt.datetime().strftime(TIMESTAMP_FORMAT)), cid)
    cur.execute(stat)

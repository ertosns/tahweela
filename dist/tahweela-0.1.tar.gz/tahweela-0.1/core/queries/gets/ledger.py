from ...connection_cursor import conn, cur
import pandas as pd
import datetime as dt

def get_transactions(st_dt, end_dt=dt.datetime()):
    """ get the transactions within the given period exclusively

    @param st_dt: the start datetime
    @param end_dt: the end datetime
    @return dataframe of the transactions
    """
    stat = "SELECT * FROM ledger WHERE trx_dt>'{}' AND trx_dt<'{}';".format((st_dt, end_dt))
    return pd.read_sql(conn, stat)

def get_sells(dest, st_dt, end_dt=None):
    """ get sells transaction within the st_dt, end_dt period, while there destined to dest (CALLED AT SERVER SIDE)
    @param dest: the destination credential id
    @return sells transactions
"""
    trx=get_transactions(st_dt, end_dt).to_json()
    trx.apply(lambda x:x['trx_dest']==dest, inplace=True)
    return trx

def get_last_timestamp():
    query="SELECT currval(pg_get_serial_sequence('ledger', 'trx_id'));"
    cur.execute(query)
    return cur.fetchone()[0]

from ...connection_cursor import conn
import pandas as pd

def get_all():
    query = "SELECT * FROM contacts;"
    return pd.read_sql(query, conn)

def get_banking_id(cid):
    """ called at the client side, to retrieve the stored banking id in the contacts

    @param cid: contact id
    @return banking_id or the associated banking id for the given contact id
    """
    query="SELECT (bank_account_id) FROM contacts WHERE contact_id='{}' LIMIT 1".format(cid)
    return pd.read_sql(query, conn).ix[0]

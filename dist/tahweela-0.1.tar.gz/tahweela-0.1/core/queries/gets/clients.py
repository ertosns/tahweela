from ...connection_cursor import conn, cur
from .banking import get_client_id, get_banking_id

import pandas as pd

def get_all():
    query="SELECT * FROM clients;"
    return pd.read_sql(query, conn)

def get(cid):
    query="SELECT (id, contact_name, client_join_dt) FROM clients WHERE id={};".format(cid)
    cur.execute(query)
    return cur.fetchone()

def get_name(cid):
    return get(cid)[1]

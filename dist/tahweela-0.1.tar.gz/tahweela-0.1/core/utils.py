TIMESTAMP_FORMAT = "%Y-%m-%d %H:%M:%S.%f"
FEE = 0.01 #this is the transaction fee in dollar
QUALITY_REDUCTION = 0.1 # this is the reduction in the quality of good per transaction
MAX_COST=1000000
MAX_GOODS=100
SERVER_URL="http://localhost:5000/api/v0.1/goods"
REGISTER_URL="http://localhost:5000/api/v0.1/register"
LEDGER_URL="http://localhost:5000/api/v0.1/ledger"
MAX_CRED_ID=9223372036854775807 #8bytes postgresql bigint max
MAX_BALANCE=MAX_COST*10
STOCHASTIC_TRADE_THRESHOLD=0.9
db_configs="dbname='demo'  user='tahweela' password='tahweela'"

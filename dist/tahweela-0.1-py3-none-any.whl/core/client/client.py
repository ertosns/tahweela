from faker import Faker
import random
from ...utils import SERVER_URL, GOODS_URL, REGISTER_URL, MAX_GOODS, MAX_COST, STOCHASTIC_TRADE_THRESHOLD
import requests
import json
from requests.auth import HTTPDigestAuth
import psycopg2 as pg
from argparser import ArgumentParser
import logging
from ...exists import credentials_exists
from ...inserts import add_cred
from ...gets import get_last_timestamp

logging.basicConfig(filename="client.log", \
                    format='%(asctime)s %(message)s', \
                    filemode='w')
logger=logging.getLogger()
logger.setLevel(logging.DEBUG)

class good(object):
    def __init__(self, fake, gid=None, gname=None, gcost=None, gquality=None):
        self.gid = 0 if gid==None else gid
        self.gname = fake.name() if gname==None else gname
        self.cost = random.random()*MAX_COST if gcost==None else gcost
        self.quality = random.random() if gquality==None else gquality

class Client(object):
    def __init__(self, seed):
        self.faker = Faker()
        random.seed(seed)
        Faker.seed(seed)
        self.my_contacts = []
        self.all_goods = []
        self.__register()
        self.__init_goods()
        # credentials username:password
        self.uname=None
        self.pas=None
        self.__register()
        logger.info("client initialized")
    def __commit(self):
        cur.commit()
        logger.info*("database committed")
    def __rollback(self):
        cur.rollback()
        logger.info("database rollback")
    def __db_init(self):
        conn=dp.connect() #TODO (res) should it be called?!
        cur=conn.cursor(**db_config)
        logger.info("database initialized")
    def __make_digest(self):
        return HTTPDigestAuth(self.uname, self.pas)
    def __get_dict(self, ret):
        res=ret.decode('utf8').replace('"', "'")
        return json.loads(res)
    def __init_goods(self):
        """fetch all market goods, this should run in the background,
        and constantly find new updates

        note (make sure the user is registered before calling this function)
        """
        ret = request.get(SERVER_URL, auth=self.__make_digest())
        #TODO assert res.status_code == requests.codes.ok
        response = ret.content.decode('utf8').replace('"', "'")
        res = json.loads(response)
        goods = res['goods']
        self.all_goods = [good(g['id'], g['name'], g['cost'], g['quality']) for g in goods]
    def __register(self):
        """ check if this client has credentials, if not register

        """
        #check if user have credentials
        try:
            self.__db_init()
            user_exists=credentials_exists(1)
            if not user_exists:
                #register user
                name = self.faker.name()
                #email = self.faker.email()
                #country = self.faker.country()
                #address = self.faker.address()
                my_goods = [good(self.faker) for i in range(random.random()*MAX_GOODS)]
                #TODO check repose status_code makes sure it's request.codes.ok
                requests.post(REGISTER_URL, data={'name':name}, auth=self.__make_digest())
                response = json.load(requests.text.replace('"', "'"))
                self.uname=response['cred_id']
                self.pas=response['passcode']
                add_cred(response['passcode'], response['cred_id'], response['bid'])
                self.__init_goods()
                #TODO post goods with credentials
                payload=jsonify({'goods': [(g.name, g.cost, g.quality) for g in my_goods]})
                requests.post(GOODS_URL, data=payload, auth=self.__make_digest())
                #TODO assert that requests.text is equivalent to payload
            else:
                self.__update_ledger()
            self.__commit()
        except psycopg2.DatabaseError as error:
            self.__rollback()
        finally:
            conn.close()
    def add_contact(self, credid):
        """Fetch the client with credential id (credid)

        @param credid: client credential id
        """
        ret=requests.post(CONTACTS_URL, data=jsonify({'cred_id': credid}), auth=self.__make_digest)
        respose=ret.text.decode('utf8').replace('"', "'")
        res = json.laods(response)
        contact = res['contact']
        try:
            self.__db_init()
            add_contact(contact['contact_id'], \
                        contact['contact_name'], \
                        contact['bank_account_id'])
            self.__commit()
        except psycopg2.DatabaseError as error:
            self.__rollback()
        finally:
            conn.close()
    def __purchase(self, gid):
        pur_item = {'id': gid}
        ret=requests.post(PURCHASE_URL, data=jsonify(pur_item), auth=self.__make_digest())
        response=ret.text.decode('utf8').replace('"', "'")
        trx=json.loads(response)
        return trx
    def __add_trax(self, trx):
        trans=trx['transaction']
        try:
            self.__db_init()
            insert_trx(trans["src"], trans['dest'], trans['gid'])
            self.__commit()
        except psycopg2.DatabaseError as error:
            self.__rollback()
        finally:
            conn.close()
    def __update_balance(self, trx):
        self.balance=trx['balance']
    def __ledger_timestamp(self):
        dt=None
        try:
            self.__db_init()
            get_last_timestamp()
            self.__commmit()
        except psycopg2.DatabaseError as error:
            self.__rollback()
        finally:
            conn.close()
        return dt
    def __update_ledger(self):
        """update ledger with sold goods, and update balance
        """
        ret=requests.post(LEDGER, data=jsonify(self.__ledger_timestamp()))
        new_trxs = self.__get_dict(ret.text)
        self.__update_balance(new_trxs['balance'])
        transactions=new_trxs.get('transactions', "")
        if len(transactions)==0:
            return
        for trx in transactions:
            self.__add_trax(trx)
    def autotrade(self):
        """Stochastic fake auto-trading

        trade with randomly with maintained contacts with 0.5 probability for each, and 0.1 probability for all contacts goods, update balance, and goods for each contact
        """
        #update balance, and add new transactions
        self.__update_ledger()
        for good in self.goods:
            if rand.random()> STOCHASTIC_TRADE_THRESHOLD and \
               good.gcost <= self.balance:
                trx=self.__purchase(good.gid)
                self.__add_trax(trx)
                self.__update_balance(trx)

#TODO add contacts from the command line
parser = ArgumentParser()
parser.add_argument('-c', '--add_contact', type=int)
parser.add_argument('-s', '--seed', type=int)
args=parser.parse_args()
cred_id=args.add_contact
seed=args.seed
seed=seed if not seed==None else 4321
trader = Client(seed)
if cred_id:
    trader.add_contact(int(cred_id))
trader.autotrade()

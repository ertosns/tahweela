from flask import request, Flask, jsonify
from flask_httpauth import HTTPBasicAuth
import json
import random as rand
import psycopg2 as pg
import logging
from core.connection_cursor import conn, cur
from core.utils import REGISTER_URL, GOODS_URL, MAX_GOODS, MAX_COST, MAX_BALANCE, db_config
from ...queries.inserts import register, insert_client, add_good
from ...queries.gets import credid2cid, get_banking_id, get_name, get_goods, get_balance, get_new_price
from ...queries.updates import update_account
#from argparser import ArgumentParser

logging.basicConfig(filename="server.log", \
                    format='%(asctime)s %(message)s', \
                    filemode='w')
logger=logging.getLogger()
logger.setLevel(logging.DEBUG)

app = Flask()
auth = HTTPBasicAuth()

class Server(object):
    def __init__(self):
        self.client_passcode=None # credential pass-code
        self.client_cid=None #credential id
        logger.info("server initialized")
    def __commit(self):
        cur.commit()
        logger.debug("database committed")
    def __rollback(self):
        cur.rollback()
        logger.debug("database rollback")
    def __db_init(self):
        conn=dp.connect() #TODO (res) should it be called?!
        cur=conn.cursor(**db_config)
        logger.debug("database re-initialized")
    @auth.get_password
    def __authenticate(username):
        logger.info("authenticating client")
        try:
            self.__db_init()
            pass_code= get_password(username)
            logger.info("username:"+username+", passcode:"+pass_code)
            self.__commit()
        except  psycopg2.DatabaseError as error:
            self.__rollback()
            logger.critical("authentication failed with error: "+error)
            abort(300)
        finally:
            logger.info("successful authentication")
            conn.close()
        self.client_passcode=pass_code
        self.client_cred_id=username
        return pass_code
    @auth.error_handler
    def __unauthorized():
        return make_response(jsonify({'error': "forbidden access"}), 403)
    @app.route(SERVER_URL, methods=['POST'])
    def __register(self):
        logger.info("registering trader...")
        if not request.json or 'name' not in request.json:
            abort(400)
        cred_id=None
        passcode=None
        bid=None
        try:
            self.__db_init()
            cid=add_client(json['name'])
            cred_id, passcode = register(cid)
            #TODO add banking account, and initialize balance
            bid=add_account(cid, rand.random()*MAX_BALANCE)
            self.__commit()
        except pycopg2.DatabaseError as error:
            self.__rollback()
            logger.critical("registering failed, error: "+error)
            abort(300)
        finally:
            conn.close()
            logger.info("successful registering")
        res = {'cred_id': cred_id,
                   'passcode': passcode,
                   'bid': bid}
        return jsonify(res), 201
    @app.route(GOODS_URL, method=['POST'])
    @auth.login_required
    def __add_goods(self):
        logger.info("adding new good to the market")
        #TODO goods should be passed with authentication,
        # how to authenticate both in requests, and in flask
        if not request.json or 'goods' not in request.json:
            abort(401)
        if 'passcode' not in request.json:
            abort(401)
        #TODO remove this no longer required
        goods={}
        try:
            self.__db_init()
            cid=credid2cid(self.client_cred_id)
            if cid==None:
                abort(403)
            goods=request.json['goods']
            for good in goods:
                gid=add_good(good[0], good[1], good[2])
                assign_owner(cid, gid)
            self.__commit()
        except pycopg2.DatabaseError as error:
            self.__rollback()
            logger.critical("error adding good, error: "+error)
            abort(300)
        finally:
            conn.close()
            logger.info("good successful added")
        return jsonify(goods), 201
    @app.route(GOODS_URL, method=['GET'])
    @auth.login_required
    def __get_goods(self):
        logger.info("requesting good")
        goods={}
        try:
            self.__db_init()
            goods = get_goods()
            self.__commit()
        except pycopg2.DatabaseError as error:
            self.__rollback()
            logger.critical("process failed, error: "+error)
            abort(300)
        finally:
            conn.close()
            logger.info("successful retrieval")
        #TODO change column names
        return goods._to_json(), 201
    @app.route(CONTACT_URL, method=['POST'])
    @auth.login_required
    def __get_contact(self):
        logger.info("requesting contact")
        if not request.json:
            abort(401)
        req=request.json
        payload={}
        try:
            self.__db_init()
            cid=credid2cid(req['cred_id']) # remote contact cred_id
            bid=get_banking_id(cid)
            # get name given cid
            name=get_name(cid)
            payload = {"contact_id": cid,
                       "contact_name": name,
                       "bank_account_id": bid}
            self.__commit()
        except pycopg2.DatabaseError as error:
            self.__rollback()
            logger.critical("requesting failed, error:"+error)
            abort(300)
        finally:
            conn.close()
            logger.info("successful retrieval")
        return jsonify(payload), 201
    def __get_balance(self):
        """ get balance of the current client
        """
        balance=None
        logger.info("balance requested")
        try:
            self.__db_init()
            balance=get_balance(self.client_cred_id)
            self.__commit()
        except pycopg2.DatabaseError as error:
            self.__rollback()
            logger.critical("failed request, error: "+error)
            abort(300)
        finally:
            conn.close()
            logger.info("successful retrieval")
        return balance
    @app.route(LEDGER_URL, method['POST'])
    @auth.login_required
    def __update_ledger(self):
        logger.info("requesting ledger update")
        if not request.json:
            abort(401)
        req=request.json
        st_dt=req['trax_dt']
        payload={}
        try:
            self.__db_init()
            sells_trax=get_sells(self.client_cred_id, st_dt).to_json()
            payload={'transactions': sells_trax,
                     'balance': self.__get_balance() }
            self.__commit()
        except pycopg2.DatabaseError as error:
            self.__rollback()
            logger.critical("request failure, error: "+ error)
            abort(300)
        finally:
            conn.close()
            logger.info("request succeeded")
        return jsonify(payload), 201
    @app.route(PURCHASE_URL, method=['POST'])
    @auth.login_required
    def __make_purchase(self):
        logger.info("making purchase")
        if not request.json:
            abort(401)
        req=request.json
        gid=req['id']
        try:
            self.__db_init()
            # cross reference owner_id, with good_id, with credentials
            # return credential id of the owner
            credid=get_credit_with_gid(gid)
            # make, and add new transaction such that increase,
            # and decrease of the src/des balance need to be performed in single transaction, then add the transactioin to the ledger, if failed rollback
            cost=get_new_price(gid)+FEE
            src_balance=get_balance(self.client_cred_id)-(cost+FEE)
            des_balance=get_balance(credid)+cost
            src_cid=self.__credid2cid(self.client_cred_id)
            des_cid=self.__credid2cid(credid)
            update_account(src_cid, src_balance)
            update_account(des_cid, des_balance)
            trx = {'trx_dest': des_credid,
                   'trx_src': src_credid,
                   'good_id': gid}
            payload={'balance': src_balance,
                     'transactions': trx}
            self.__commit()
        except pycopg2.DatabaseError as error:
            self.__rollback()
            logger.critical("purchase failed, error: "+error)
            abort(300)
        finally:
            conn.close()
            logger.info("purchase successful")
        return jsonify(payload), 201

server = Server()

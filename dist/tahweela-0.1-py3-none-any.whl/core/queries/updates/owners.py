from ...connection_cursor import cur

def update_owner(gid):
    """reassign the good's ownership with corresponding gid

    @param gid: good id
    """
    stat = "UPDATE owners SET (owner_id) = {} WHERE good_id={}".\
        format(owner_id, bid)
    cur.execute(stat)

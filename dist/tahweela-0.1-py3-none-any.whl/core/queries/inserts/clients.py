from ...connection_cursor import cur

def insert_client(name):
    """ add new client to the network (CALLED AT THE SERVER SIDE),

    note that some clients might not have banking id yet
    @param name: client name
    """
    stat="INSERT INTO clients (contact_name) VALUES ('{}')".format(name)
    cur.execute(stat)
    cur.execute("SELECT currval('id');")
    return cur.fetchone()[0]

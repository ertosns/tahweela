from ...connection_cursor import cur
import datetime as dt
from ...utils import TIMESTAMP_FORMAT

def insert_client_id(cid, balance):
    """ give the client with the given id (cid) banking account (CALLED AT SERVER SIDE)

    @param cid: client id
    @param balance: client account balance
    """
    stat="INSERT INTO banking (client_id, balance, balance_dt) VALUES ('{}', '{}', '{}')". \
        format((cid, balance, dt.datetime().strftime(TIMESTAMP_FORMAT)))
    cur.execute(stat)
    cur.execute("SELECT currval(pg_get_serial_sequence('banking', 'id'));");
    return cur.fetchone()[0]

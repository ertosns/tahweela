from ...connection_cursor import cur

def add_owner(oid, gid):
    """assign ownership of owner with id (oid) to the good with id (gid)

    @param oid: owner id
    @param gid: good id
    """
    stat="INSERT INTO owners (owner_id, good_id) VALUES ('{}', '{}')".format(oid, gid)
    cur.execute(stat)

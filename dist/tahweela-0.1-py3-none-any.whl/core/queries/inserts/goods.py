from ...connection_cursor import cur

def add_good(gname, gquality, gcost, gcid=1):
    """ INSERT new good into the goods table

    @param gname: good name
    @param gquality: good quality
    @param gcost: good cost
    @param gcid: good currency id
    """
    stat="INSERT INTO goods (good_name, good_quality, good_cost, good_currency_id) VALUES ('{}', '{}', '{}', '{}'})".format(gname, gquality, gcost, gcid)
    cur.execute(stat)
    cur.execute("SELECT currval(pg_get_serial_sequence('goods', 'id'));")
    return cur.fetchone()[0]

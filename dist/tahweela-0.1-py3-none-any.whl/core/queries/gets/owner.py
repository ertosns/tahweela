import pandas as pd
from ...connection_cursor import conn

def get_all():
    query="SELECT * FROM owner;"
    return pd.read_sql(query, conn, index_col='id')

def get_good_owner(gid):
   """return owner id (oid) for the given gid

   @param gid: good
   @return oid: is the owner id
   """
   query = "SELECT (owner_id) FROM owners WHERE good_id='{}'".format(gid)
   return pd.read_sql(query, conn).ix[0]

def get_owner_goods(oid):
   """return the good assigned to the given owner id (oid)

   @param oid: is the owner id

   """
   query = "SELECT (owner_id) FROM owners WHERE good_id='{}'".format(gid)
   return pd.read_sql(query, conn).ix[0]

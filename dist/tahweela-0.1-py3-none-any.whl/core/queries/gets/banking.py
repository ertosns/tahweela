from ...connection_cursor import conn, cur
import pandas as pd

def get_client_id(bid):
    """called at the server side to retrieve the corresponding client_id of the given,
    banking_id (bid)

    @param bid: banking id
    @return cid: contact id
    """
    query="SELECT (client_id) FROM banking WHERE id='{}' LIMIT 1".format(bid)
    return pd.read_sql(query, conn).ix[0]

def get_banking_id(cid):
    """called at the server side to retrieve the corresponding banking_id of the given
    client_id (cid)

    @param cid: client id
    @return bid: banking id
    """
    query="SELECT (id) FROM banking WHERE client_id='{}' LIMIT 1".format(cid)
    return pd.read_sql(query, conn).ix[0]

def get_banking_balance(cid):
    """called at the server side to retrieve the account balance d of the given client_id (cid)

    @param cid: client id
    @return bid: banking id
    """
    query="SELECT (balance) FROM banking WHERE client_id='{}' LIMIT 1".format(cid)
    return pd.read_sql(query, conn).ix[0]

def get_balance(cred_id):
    """ get balance of client with given credential id

    @param cred_id: client credential id
    """
    query="SELECT (b.balance) FROM banking as b JOIN WITH credentials AS c WHERE c.cred_id={} AND c.id==b.client_id;"
    cur.execute(query)
    return cur.fetchone()[0]

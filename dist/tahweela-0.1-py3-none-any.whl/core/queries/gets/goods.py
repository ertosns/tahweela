import pandas as pd
from ...connection_cursor import conn
from currency import to_dollar

def get_all():
    query="SELECT * FROM goods;"
    return pd.read_sql(query, conn, index_col='id')

def get_good(gid):
    """retrive good for the given goods id (gid)

    @param gid: goods id
    @return pandas data series of the corresponding row
    """
    query = "SELECT * FROM goods WHERE id='{}'".format(gid)
    return pd.read_sql(query, conn)

def get_commodity(gname, quality=0):
    """retrive good for the given goods constraints

    @param gname: goods name
    @param quality: retrieve goods with quality > given threshold
    @return pandas data frame of the corresponding constrains
    """
    query = "SELECT * FROM goods WHERE good_name='{}' AND good_quality>='{}'".format(gname, quality)
    return pd.read_sql(query, conn)

def get_new_price(gid):
    df = get_good(gid)
    cur_id = df['good_currency_id'].ix[0]
    return df['good_cost'].ix[0]*to_dollar(cur_id)
